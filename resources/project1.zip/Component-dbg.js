sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend("project1.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
